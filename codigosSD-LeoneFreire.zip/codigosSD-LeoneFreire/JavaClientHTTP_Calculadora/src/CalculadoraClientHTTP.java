//importando classe para leitura de dados inputados
import java.io.BufferedReader;
//importando classe que envia todos os comandos de escrita para um buffer
import java.io.BufferedWriter;
//importando classe para tratamento de exce��es
import java.io.IOException;
//importando classe adaptadora para ler bytes e transformar em caracteres reconheciveis pelo cliente
import java.io.InputStreamReader;
//importando superclasse de todas as classes que possuem bytes como sa�da em stream
import java.io.OutputStream;
//importando classe que converte caracteres inputados em bytes
import java.io.OutputStreamWriter;
//importando classe para identifica��o de URL, apontando para o respectivo enreder�o na WWW
import java.net.URL;

//importando classe para uso de URL e estabelecimento de conex�o
import javax.net.ssl.HttpsURLConnection;

public class CalculadoraClientHTTP {

	public static void main(String[] args) {
	
	//declarando vari�vel que ser� usada para receber o resultado
	String result="";
    try {

       //instanciando novo objeto URL
       URL url = new URL("https://double-nirvana-273602.appspot.com/?hl=pt-BR");
       //nova vari�vel que recebe uma conex�o
       HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.setReadTimeout(10000);
        conn.setConnectTimeout(15000);
        conn.setRequestMethod("POST"); //tipo de conex�o
        conn.setDoInput(true);
        conn.setDoOutput(true) ;

        //ENVIO DOS PARAMETROS
        OutputStream os = conn.getOutputStream();
        BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(os, "UTF-8"));
        writer.write("oper1=15&oper2=15&operacao=3"); //1-somar 2-subtrair 3-dividir 4-multiplicar
        writer.flush();
        writer.close();
        os.close();

        int responseCode=conn.getResponseCode();
        if (responseCode == HttpsURLConnection.HTTP_OK) {

            //RECBIMENTO DOS PARAMETROS


            //novo objeto para leitura dos dados inputados
        	BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "utf-8")); //transformando os bytes em caracteres reconheciveis pelo cliente
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            result = response.toString();
            System.out.println("Resposta do Servidor PHP="+result); //printando resultado para o cliente
        }
    } catch (IOException e) {
        e.printStackTrace(); //tratamento de exce��es
    }
	}
}
